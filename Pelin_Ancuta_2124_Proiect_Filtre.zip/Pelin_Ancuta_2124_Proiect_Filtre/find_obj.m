fig=findobj(gcf,'Tag','interfata_c');

BR=findobj(gcf,'Tag','rezistenta');
   

BL=findobj(gcf,'Tag','inductanta');
   

BC=findobj(gcf,'Tag','capacitate');


Pop_up_menu=findobj(gcf,'Tag','pop_menu');

Pop_up_menu2=findobj(gcf,'Tag','pop_menu_cstv');

Pop_up_menu3=findobj(gcf,'Tag','pop_menu_sr');

Pop_up_menu4=findobj(gcf,'Tag','pop_menu_r');

%Pop_up_menur=findobj(gcf,'Tag','rezistenta');

%Pop_up_menuc=findobj(gcf,'Tag','capacitate');


